"""
=============================================================
 STRATÉGIE DE TRADING BASÉE SUR LA DIVERGENCE MATHÉMATIQUE
 Inspirée du concept div F = ∇·F = ∂P/∂x + ∂Q/∂y + ∂R/∂z
=============================================================
 F = (P, Q, R) où :
   P = momentum du prix (∂P/∂x)
   Q = anomalie de volume (∂Q/∂y)
   R = variation du RSI comme proxy d'OI (∂R/∂z)
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

import warnings
warnings.filterwarnings('ignore')

# ─────────────────────────────────────────────────────────────
# 1. PARAMÈTRES
# ─────────────────────────────────────────────────────────────
TICKER       = "BTC-USD"
START        = "2023-01-01"
END          = "2025-01-01"
CAPITAL      = 10_000          # Capital initial ($)
RISK_PCT     = 0.02            # Risque par trade (2%)
WINDOW       = 14              # Fenêtre des dérivées
DIV_LONG     = 0.15            # Seuil divergence positive → LONG
DIV_SHORT    = -0.15           # Seuil divergence négative → SHORT
STOP_MULT    = 1.5             # Stop = 1.5 × ATR
TP_MULT      = 2.5             # TP   = 2.5 × ATR


# ─────────────────────────────────────────────────────────────
# 2. TÉLÉCHARGEMENT DES DONNÉES
# ─────────────────────────────────────────────────────────────
print(f"📊 Génération de données synthétiques BTC-like ({START} → {END})...")
np.random.seed(42)
dates = pd.date_range(START, END, freq="D")
n = len(dates)

# Simulation GBM (Geometric Brownian Motion) réaliste pour BTC
price = 16_500.0
prices = [price]
for _ in range(n - 1):
    ret = np.random.normal(0.0015, 0.035)
    price = price * np.exp(ret)
    prices.append(price)
prices = np.array(prices)

# Bougies OHLC réalistes
daily_vol = prices * np.random.uniform(0.01, 0.06, n)
highs  = prices + daily_vol * np.random.uniform(0.3, 1.0, n)
lows   = prices - daily_vol * np.random.uniform(0.3, 1.0, n)
opens  = prices * (1 + np.random.normal(0, 0.008, n))

# Volume avec cycles et spikes
vol_base   = np.random.lognormal(22, 0.5, n)
vol_spike  = np.where(np.abs(np.diff(prices, prepend=prices[0]) / prices) > 0.03,
                      vol_base * np.random.uniform(1.5, 4.0, n), vol_base)

df = pd.DataFrame({
    "Open": opens, "High": highs, "Low": lows,
    "Close": prices, "Volume": vol_spike
}, index=dates)
df.dropna(inplace=True)
print(f"✅ {len(df)} bougies simulées (GBM réaliste).\n")


# ─────────────────────────────────────────────────────────────
# 3. CALCUL DES COMPOSANTES DU CHAMP VECTORIEL
# ─────────────────────────────────────────────────────────────

# --- Composante P : dérivée du prix (momentum normalisé) ---
df["dP"] = df["Close"].pct_change(WINDOW)

# --- Composante Q : anomalie de volume normalisée ---
vol_moy = df["Volume"].rolling(WINDOW * 2).mean()
vol_std = df["Volume"].rolling(WINDOW * 2).std()
df["dQ"] = (df["Volume"] - vol_moy) / (vol_std + 1e-9)
df["dQ"] = df["dQ"].clip(-3, 3) / 3          # normalise [-1, 1]

# --- Composante R : dérivée du RSI (proxy d'Open Interest) ---
delta  = df["Close"].diff()
gain   = delta.clip(lower=0).rolling(WINDOW).mean()
loss   = (-delta.clip(upper=0)).rolling(WINDOW).mean()
rs     = gain / (loss + 1e-9)
df["RSI"] = 100 - (100 / (1 + rs))
df["dR"]  = df["RSI"].diff(WINDOW) / 100      # normalise [-1, 1]

# --- Score de Divergence global ---
df["div_score"] = df["dP"] + df["dQ"] + df["dR"]

# --- ATR pour stop/TP dynamiques ---
df["ATR"] = (df["High"] - df["Low"]).rolling(WINDOW).mean()

df.dropna(inplace=True)


# ─────────────────────────────────────────────────────────────
# 4. GÉNÉRATION DES SIGNAUX
# ─────────────────────────────────────────────────────────────
df["Signal"] = 0
df.loc[df["div_score"] >  DIV_LONG,  "Signal"] =  1   # LONG
df.loc[df["div_score"] <  DIV_SHORT, "Signal"] = -1   # SHORT


# ─────────────────────────────────────────────────────────────
# 5. MOTEUR DE BACKTEST
# ─────────────────────────────────────────────────────────────
equity       = CAPITAL
position     = 0          # 0 = neutre, 1 = long, -1 = short
entry_price  = 0.0
stop_price   = 0.0
tp_price     = 0.0
qty          = 0.0

trades       = []
equity_curve = []

for i, row in df.iterrows():
    price  = row["Close"]
    signal = row["Signal"]
    atr    = row["ATR"]
    div    = row["div_score"]

    # ── Gestion de la position ouverte ──────────────────────
    if position == 1:                          # Long ouvert
        if price <= stop_price:
            pnl = (price - entry_price) * qty
            equity += pnl
            trades.append({"date": i, "type": "LONG", "entry": entry_price,
                           "exit": price, "pnl": pnl, "reason": "Stop"})
            position = 0
        elif price >= tp_price:
            pnl = (price - entry_price) * qty
            equity += pnl
            trades.append({"date": i, "type": "LONG", "entry": entry_price,
                           "exit": price, "pnl": pnl, "reason": "TP"})
            position = 0
        elif signal == -1:                     # Signal inverse → sortie
            pnl = (price - entry_price) * qty
            equity += pnl
            trades.append({"date": i, "type": "LONG", "entry": entry_price,
                           "exit": price, "pnl": pnl, "reason": "Signal"})
            position = 0

    elif position == -1:                       # Short ouvert
        if price >= stop_price:
            pnl = (entry_price - price) * qty
            equity += pnl
            trades.append({"date": i, "type": "SHORT", "entry": entry_price,
                           "exit": price, "pnl": pnl, "reason": "Stop"})
            position = 0
        elif price <= tp_price:
            pnl = (entry_price - price) * qty
            equity += pnl
            trades.append({"date": i, "type": "SHORT", "entry": entry_price,
                           "exit": price, "pnl": pnl, "reason": "TP"})
            position = 0
        elif signal == 1:
            pnl = (entry_price - price) * qty
            equity += pnl
            trades.append({"date": i, "type": "SHORT", "entry": entry_price,
                           "exit": price, "pnl": pnl, "reason": "Signal"})
            position = 0

    # ── Ouverture d'une nouvelle position ───────────────────
    if position == 0 and signal != 0:
        risk_amt   = equity * RISK_PCT
        stop_dist  = STOP_MULT * atr
        qty        = risk_amt / (stop_dist + 1e-9)
        entry_price = price
        position    = signal

        if signal == 1:
            stop_price = price - stop_dist
            tp_price   = price + TP_MULT * atr
        else:
            stop_price = price + stop_dist
            tp_price   = price - TP_MULT * atr

    equity_curve.append({"date": i, "equity": equity})

# Fermer la position finale
if position != 0 and len(df) > 0:
    last_price = df["Close"].iloc[-1]
    last_date  = df.index[-1]
    if position == 1:
        pnl = (last_price - entry_price) * qty
    else:
        pnl = (entry_price - last_price) * qty
    equity += pnl
    trades.append({"date": last_date, "type": "LONG" if position==1 else "SHORT",
                   "entry": entry_price, "exit": last_price, "pnl": pnl, "reason": "Fin"})

equity_curve.append({"date": df.index[-1], "equity": equity})


# ─────────────────────────────────────────────────────────────
# 6. STATISTIQUES
# ─────────────────────────────────────────────────────────────
ec  = pd.DataFrame(equity_curve).set_index("date")
tdf = pd.DataFrame(trades)

total_return = (equity - CAPITAL) / CAPITAL * 100
nb_trades    = len(tdf)
nb_win       = (tdf["pnl"] > 0).sum() if nb_trades else 0
win_rate     = nb_win / nb_trades * 100 if nb_trades else 0
avg_win      = tdf[tdf["pnl"] > 0]["pnl"].mean() if nb_win else 0
avg_loss     = tdf[tdf["pnl"] <= 0]["pnl"].mean() if nb_trades - nb_win > 0 else 0
profit_factor = abs(tdf[tdf["pnl"]>0]["pnl"].sum() / (tdf[tdf["pnl"]<=0]["pnl"].sum() + 1e-9))

# Drawdown
peak      = ec["equity"].cummax()
drawdown  = (ec["equity"] - peak) / peak * 100
max_dd    = drawdown.min()

# Sharpe (daily)
daily_ret = ec["equity"].pct_change().dropna()
sharpe    = (daily_ret.mean() / (daily_ret.std() + 1e-9)) * np.sqrt(252)

# Buy & Hold
bh_return = (df["Close"].iloc[-1] - df["Close"].iloc[0]) / df["Close"].iloc[0] * 100

print("=" * 55)
print("       RÉSULTATS DU BACKTEST — DIVERGENCE TRADING")
print("=" * 55)
print(f"  Ticker         : {TICKER}")
print(f"  Période        : {START} → {END}")
print(f"  Capital initial: ${CAPITAL:,.0f}")
print(f"  Capital final  : ${equity:,.2f}")
print(f"  Rendement      : {total_return:+.2f}%")
print(f"  Buy & Hold     : {bh_return:+.2f}%")
print(f"  Nb trades      : {nb_trades}")
print(f"  Win Rate       : {win_rate:.1f}%")
print(f"  Profit Factor  : {profit_factor:.2f}")
print(f"  Gain moyen     : ${avg_win:,.2f}")
print(f"  Perte moyenne  : ${avg_loss:,.2f}")
print(f"  Max Drawdown   : {max_dd:.2f}%")
print(f"  Sharpe Ratio   : {sharpe:.2f}")
print("=" * 55)


# ─────────────────────────────────────────────────────────────
# 7. VISUALISATION
# ─────────────────────────────────────────────────────────────
fig = plt.figure(figsize=(16, 12), facecolor="#0d1117")
gs  = gridspec.GridSpec(4, 1, height_ratios=[3, 1.5, 1.5, 1], hspace=0.06)

colors = {"bg": "#0d1117", "text": "#e6edf3", "grid": "#21262d",
          "long": "#3fb950", "short": "#f85149", "div": "#79c0ff",
          "equity": "#d2a8ff", "bh": "#ffa657", "dd": "#ff7b72"}

# ── Panel 1 : Prix + signaux ──────────────────────────────
ax1 = fig.add_subplot(gs[0])
ax1.set_facecolor(colors["bg"])
ax1.plot(df["Close"], color="#58a6ff", linewidth=1.2, label="Prix", zorder=2)

longs  = tdf[tdf["type"] == "LONG"]
shorts = tdf[tdf["type"] == "SHORT"]
for _, t in tdf.iterrows():
    color = colors["long"] if t["type"] == "LONG" else colors["short"]
    ax1.axvline(t["date"], color=color, alpha=0.15, linewidth=0.8)

# Marqueurs d'entrée depuis df
long_entries  = df[df["Signal"] ==  1]["Close"]
short_entries = df[df["Signal"] == -1]["Close"]
ax1.scatter(long_entries.index,  long_entries.values,
            marker="^", color=colors["long"],  s=60, zorder=5, label="LONG", alpha=0.9)
ax1.scatter(short_entries.index, short_entries.values,
            marker="v", color=colors["short"], s=60, zorder=5, label="SHORT", alpha=0.9)

ax1.set_ylabel("Prix ($)", color=colors["text"], fontsize=10)
ax1.tick_params(colors=colors["text"], labelbottom=False)
ax1.spines[["top","right","bottom","left"]].set_edgecolor(colors["grid"])
ax1.set_facecolor(colors["bg"])
for spine in ax1.spines.values():
    spine.set_color(colors["grid"])
ax1.yaxis.label.set_color(colors["text"])
ax1.tick_params(axis='y', colors=colors["text"])
ax1.grid(axis="y", color=colors["grid"], linewidth=0.5)
ax1.legend(loc="upper left", fontsize=8, facecolor="#161b22", edgecolor=colors["grid"],
           labelcolor=colors["text"])
ax1.set_title(f"Stratégie Divergence Mathématique — {TICKER}  |  {START} → {END}",
              color=colors["text"], fontsize=13, fontweight="bold", pad=10)

# ── Panel 2 : Score de Divergence ────────────────────────
ax2 = fig.add_subplot(gs[1], sharex=ax1)
ax2.set_facecolor(colors["bg"])
ax2.axhline(DIV_LONG,  color=colors["long"],  linestyle="--", linewidth=1, alpha=0.7)
ax2.axhline(DIV_SHORT, color=colors["short"], linestyle="--", linewidth=1, alpha=0.7)
ax2.axhline(0, color=colors["text"], linewidth=0.5, alpha=0.3)
ax2.fill_between(df.index, df["div_score"], 0,
                 where=df["div_score"] > 0, color=colors["long"],  alpha=0.3)
ax2.fill_between(df.index, df["div_score"], 0,
                 where=df["div_score"] < 0, color=colors["short"], alpha=0.3)
ax2.plot(df["div_score"], color=colors["div"], linewidth=1, label="div F̄")
ax2.set_ylabel("div F̄", color=colors["text"], fontsize=10)
ax2.tick_params(colors=colors["text"], labelbottom=False)
for spine in ax2.spines.values():
    spine.set_color(colors["grid"])
ax2.tick_params(axis='y', colors=colors["text"])
ax2.grid(axis="y", color=colors["grid"], linewidth=0.5)
ax2.legend(loc="upper left", fontsize=8, facecolor="#161b22",
           edgecolor=colors["grid"], labelcolor=colors["text"])

# ── Panel 3 : Courbe d'équité ─────────────────────────────
ax3 = fig.add_subplot(gs[2], sharex=ax1)
ax3.set_facecolor(colors["bg"])

# Buy & Hold equity
bh_prices = df["Close"] / df["Close"].iloc[0] * CAPITAL
ax3.plot(bh_prices.index, bh_prices.values,
         color=colors["bh"], linewidth=1, alpha=0.7, linestyle="--", label=f"Buy & Hold ({bh_return:+.1f}%)")
ax3.plot(ec.index, ec["equity"],
         color=colors["equity"], linewidth=1.5, label=f"Stratégie ({total_return:+.1f}%)")
ax3.fill_between(ec.index, ec["equity"], CAPITAL,
                 where=ec["equity"] >= CAPITAL, color=colors["long"],  alpha=0.15)
ax3.fill_between(ec.index, ec["equity"], CAPITAL,
                 where=ec["equity"] <  CAPITAL, color=colors["short"], alpha=0.15)
ax3.set_ylabel("Équité ($)", color=colors["text"], fontsize=10)
ax3.tick_params(colors=colors["text"], labelbottom=False)
for spine in ax3.spines.values():
    spine.set_color(colors["grid"])
ax3.tick_params(axis='y', colors=colors["text"])
ax3.grid(axis="y", color=colors["grid"], linewidth=0.5)
ax3.legend(loc="upper left", fontsize=8, facecolor="#161b22",
           edgecolor=colors["grid"], labelcolor=colors["text"])

# ── Panel 4 : Drawdown ────────────────────────────────────
ax4 = fig.add_subplot(gs[3], sharex=ax1)
ax4.set_facecolor(colors["bg"])
ax4.fill_between(drawdown.index, drawdown.values, 0,
                 color=colors["dd"], alpha=0.5)
ax4.plot(drawdown.index, drawdown.values, color=colors["dd"], linewidth=0.8)
ax4.set_ylabel("DD (%)", color=colors["text"], fontsize=9)
ax4.tick_params(colors=colors["text"])
for spine in ax4.spines.values():
    spine.set_color(colors["grid"])
ax4.tick_params(axis='both', colors=colors["text"])
ax4.grid(axis="y", color=colors["grid"], linewidth=0.5)

# ── Tableau de stats (annotation) ────────────────────────
stats_text = (f"Rendement: {total_return:+.1f}%  |  Win Rate: {win_rate:.0f}%  |  "
              f"Trades: {nb_trades}  |  Sharpe: {sharpe:.2f}  |  "
              f"Max DD: {max_dd:.1f}%  |  Profit Factor: {profit_factor:.2f}")
fig.text(0.5, 0.01, stats_text, ha="center", color=colors["text"],
         fontsize=9, style="italic",
         bbox=dict(boxstyle="round,pad=0.4", facecolor="#161b22", edgecolor=colors["grid"]))

plt.setp(ax4.get_xticklabels(), color=colors["text"])
plt.tight_layout(rect=[0, 0.04, 1, 1])

out_path = "/mnt/user-data/outputs/divergence_backtest.png"
plt.savefig(out_path, dpi=150, bbox_inches="tight", facecolor=colors["bg"])
print(f"\n📊 Graphique sauvegardé → {out_path}")
